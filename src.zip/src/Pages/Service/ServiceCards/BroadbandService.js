import React from "react";

const BroadbandService = () => {
  return <div>BroadbandService</div>;
};

export default BroadbandService;
