import React from 'react'

const LoneService = () => {
  return (
    <div>LoneService</div>
  )
}

export default LoneService