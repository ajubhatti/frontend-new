import React from "react";

const FastagService = () => {
  return <div>FastagService</div>;
};

export default FastagService;
