import React from "react";

const GasService = () => {
  return <div>GasService</div>;
};

export default GasService;
