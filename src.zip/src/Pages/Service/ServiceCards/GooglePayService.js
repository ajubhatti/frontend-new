import React from "react";

const GooglePayService = () => {
  return <div>GooglePayService</div>;
};

export default GooglePayService;
