import React from "react";

const WaterService = () => {
  return <div>WaterService</div>;
};

export default WaterService;
