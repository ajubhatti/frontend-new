import React from "react";

const PostpaidService = () => {
  return <div>PostpaidService</div>;
};

export default PostpaidService;
