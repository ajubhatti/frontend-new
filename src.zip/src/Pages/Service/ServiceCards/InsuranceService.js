import React from "react";

const InsuranceService = () => {
  return <div>InsuranceService</div>;
};

export default InsuranceService;
