import React from "react";

const ElectricityService = () => {
  return <div>ElectricityService</div>;
};

export default ElectricityService;
