import React from "react";

const LandlineService = () => {
  return <div>LandlineService</div>;
};

export default LandlineService;
