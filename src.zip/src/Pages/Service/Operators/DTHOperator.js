export const DTHOperator = [
  {
    key: "Airtel dth",
    value: "Airtel dth",
  },
  {
    key: "Dish TV",
    value: " Dish TV",
  },
  {
    key: "Tata Sky",
    value: "Tata Sky",
  },
  {
    key: "Sun Direct",
    value: "Sun Direct",
  },
  {
    key: "Videocon",
    value: "Videocon",
  },
];
