import React from "react";

const ProfileContainer = () => {
  return <div>ProfileContainer</div>;
};

export default ProfileContainer;
