const Contain = ({ children }) => children;

export default Contain;
